/**
 * Pure TypeScript Open-Meteo API client.
 * Replaces all Python analytics scripts so the project runs on Vercel serverless.
 */

// ─── Date helpers ──────────────────────────────────────────────────────────────
/** Open-Meteo archive API has ~2-day lag, clamp end to today-2 */
function archiveEndDate(): Date {
    const d = new Date();
    d.setDate(d.getDate() - 2);
    return d;
}

function isoDate(d: Date): string {
    return d.toISOString().slice(0, 10);
}

function startDate(days: number, end: Date): Date {
    const s = new Date(end);
    s.setDate(s.getDate() - Math.max(1, days - 1));
    return s;
}

// ─── Simple in-memory cache ────────────────────────────────────────────────────
const _cache = new Map<string, { exp: number; data: any }>();

function cacheGet(key: string) {
    const e = _cache.get(key);
    if (e && e.exp > Date.now()) return e.data;
    return null;
}

function cacheSet(key: string, data: any, ttlSec = 300) {
    _cache.set(key, { exp: Date.now() + ttlSec * 1000, data });
}

// ─── Meteo Series (replaces meteo_series.py) ───────────────────────────────────
export interface TempPoint { date: string; mean: number | null }
export interface PrecipPoint { date: string; sum: number | null }
export interface MeteoSeriesResult {
    location: { lat: number; lon: number };
    period: { start: string; end: string; days: number };
    temperature: TempPoint[];
    precipitation: PrecipPoint[];
    latest: { temperature: number | null; precipitation: number | null };
}

export async function fetchMeteoSeries(
    lat: number,
    lon: number,
    days = 365,
): Promise<MeteoSeriesResult> {
    const cacheKey = `meteo:${lat}:${lon}:${days}`;
    const cached = cacheGet(cacheKey);
    if (cached) return cached;

    const end = archiveEndDate();
    const start = startDate(days, end);

    const url = new URL('https://archive-api.open-meteo.com/v1/archive');
    url.searchParams.set('latitude', String(lat));
    url.searchParams.set('longitude', String(lon));
    url.searchParams.set('start_date', isoDate(start));
    url.searchParams.set('end_date', isoDate(end));
    url.searchParams.set('daily', 'temperature_2m_mean,precipitation_sum');
    url.searchParams.set('timezone', 'auto');

    const res = await fetch(url.toString(), { next: { revalidate: 300 } });
    if (!res.ok) throw new Error(`Open-Meteo archive error: ${res.status}`);
    const d = await res.json();

    const times: string[] = d?.daily?.time ?? [];
    const temps: (number | null)[] = d?.daily?.temperature_2m_mean ?? [];
    const precips: (number | null)[] = d?.daily?.precipitation_sum ?? [];

    const temperature = times.map((t, i) => ({ date: t, mean: temps[i] ?? null }));
    const precipitation = times.map((t, i) => ({ date: t, sum: precips[i] ?? null }));

    const result: MeteoSeriesResult = {
        location: { lat, lon },
        period: { start: isoDate(start), end: isoDate(end), days },
        temperature,
        precipitation,
        latest: {
            temperature: temperature.at(-1)?.mean ?? null,
            precipitation: precipitation.at(-1)?.sum ?? null,
        },
    };
    cacheSet(cacheKey, result, 300);
    return result;
}

// ─── Air Quality Series (replaces air_quality_series.py) ───────────────────────
export interface AirQualityPoint { date: string; pm25: number | null }
export interface AirQualitySeriesResult {
    location: { lat: number; lon: number };
    period: { start: string; end: string; days: number };
    pm25: AirQualityPoint[];
    latest: { pm25: number | null };
}

export async function fetchAirQualitySeries(
    lat: number,
    lon: number,
    days = 30,
): Promise<AirQualitySeriesResult> {
    const cacheKey = `aq:${lat}:${lon}:${days}`;
    const cached = cacheGet(cacheKey);
    if (cached) return cached;

    const end = archiveEndDate();
    const start = startDate(days, end);

    const url = new URL('https://air-quality-api.open-meteo.com/v1/air-quality');
    url.searchParams.set('latitude', String(lat));
    url.searchParams.set('longitude', String(lon));
    url.searchParams.set('start_date', isoDate(start));
    url.searchParams.set('end_date', isoDate(end));
    url.searchParams.set('hourly', 'pm2_5,pm10,ozone,carbon_monoxide');
    url.searchParams.set('timezone', 'auto');

    const res = await fetch(url.toString(), { next: { revalidate: 300 } });
    if (!res.ok) throw new Error(`Open-Meteo air-quality error: ${res.status}`);
    const d = await res.json();

    const hourlyTimes: string[] = d?.hourly?.time ?? [];
    const hourlyPm25: (number | null)[] = d?.hourly?.pm2_5 ?? [];

    // Daily average of hourly pm2.5
    const dailyMap = new Map<string, { sum: number; count: number }>();
    for (let i = 0; i < hourlyTimes.length; i++) {
        const day = hourlyTimes[i].slice(0, 10);
        const v = hourlyPm25[i];
        if (v === null || v === undefined) continue;
        const entry = dailyMap.get(day) ?? { sum: 0, count: 0 };
        entry.sum += v;
        entry.count += 1;
        dailyMap.set(day, entry);
    }

    const pm25: AirQualityPoint[] = Array.from(dailyMap.entries())
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([date, { sum, count }]) => ({
            date,
            pm25: count > 0 ? Math.round((sum / count) * 10) / 10 : null,
        }));

    const result: AirQualitySeriesResult = {
        location: { lat, lon },
        period: { start: isoDate(start), end: isoDate(end), days },
        pm25,
        latest: { pm25: pm25.at(-1)?.pm25 ?? null },
    };
    cacheSet(cacheKey, result, 300);
    return result;
}

// ─── Live Weather + Air Quality (replaces live_analysis.py) ────────────────────
export interface LiveWeatherResult {
    location: { lat: number; lon: number };
    data: {
        current: Record<string, number | null>;
        air: Record<string, number | null>;
    };
}

export async function fetchLiveWeather(
    lat: number,
    lon: number,
): Promise<LiveWeatherResult> {
    const cacheKey = `live:${lat}:${lon}`;
    const cached = cacheGet(cacheKey);
    if (cached) return cached;

    const weatherUrl = new URL('https://api.open-meteo.com/v1/forecast');
    weatherUrl.searchParams.set('latitude', String(lat));
    weatherUrl.searchParams.set('longitude', String(lon));
    weatherUrl.searchParams.set(
        'current',
        'temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,wind_gusts_10m',
    );
    weatherUrl.searchParams.set('timezone', 'auto');

    const airUrl = new URL('https://air-quality-api.open-meteo.com/v1/air-quality');
    airUrl.searchParams.set('latitude', String(lat));
    airUrl.searchParams.set('longitude', String(lon));
    airUrl.searchParams.set('current', 'pm2_5,pm10,ozone,carbon_monoxide');
    airUrl.searchParams.set('timezone', 'auto');

    const [wRes, aRes] = await Promise.all([
        fetch(weatherUrl.toString(), { cache: 'no-store' }),
        fetch(airUrl.toString(), { cache: 'no-store' }),
    ]);

    if (!wRes.ok) throw new Error(`Weather API error: ${wRes.status}`);
    const wJson = await wRes.json();
    const current: Record<string, number | null> = wJson?.current ?? {};

    let air: Record<string, number | null> = {};
    if (aRes.ok) {
        const aJson = await aRes.json();
        // Try current first, fallback to last hourly
        const currentAir = aJson?.current;
        if (currentAir && Object.keys(currentAir).length > 1) {
            air = {
                pm2_5: currentAir.pm2_5 ?? null,
                pm10: currentAir.pm10 ?? null,
                ozone: currentAir.ozone ?? null,
                carbon_monoxide: currentAir.carbon_monoxide ?? null,
            };
        } else {
            const hourly = aJson?.hourly ?? {};
            for (const key of ['pm2_5', 'pm10', 'ozone', 'carbon_monoxide']) {
                const series = hourly[key];
                if (Array.isArray(series)) {
                    const lastVal = [...series].reverse().find((v) => v !== null);
                    air[key] = lastVal ?? null;
                }
            }
        }
    }

    const result: LiveWeatherResult = {
        location: { lat, lon },
        data: { current, air },
    };
    cacheSet(cacheKey, result, 30); // 30s cache for live data
    return result;
}

// ─── Linear Regression (replaces numpy polyfit) ────────────────────────────────
export function linearRegression(
    xs: number[],
    ys: number[],
): { slope: number; intercept: number } {
    const n = xs.length;
    if (n < 2) {
        return { slope: 0, intercept: ys[0] ?? 0 };
    }
    const xMean = xs.reduce((a, b) => a + b, 0) / n;
    const yMean = ys.reduce((a, b) => a + b, 0) / n;
    const num = xs.reduce((acc, x, i) => acc + (x - xMean) * (ys[i] - yMean), 0);
    const den = xs.reduce((acc, x) => acc + (x - xMean) ** 2, 0);
    const slope = den ? num / den : 0;
    const intercept = yMean - slope * xMean;
    return { slope, intercept };
}

// ─── Predictions (replaces predictions.py) ─────────────────────────────────────
export interface ForecastPoint { year: number; pred: number }
export interface PredictionsResult {
    generatedAt: string;
    horizonYears: number;
    temperatureForecast: { slope: number; intercept: number; forecast: ForecastPoint[] };
    co2Forecast: { slope: number; intercept: number; forecast: ForecastPoint[] };
    location: { lat: number; lon: number };
    source: string;
}

export async function buildPredictions(
    lat: number,
    lon: number,
    days = 365,
    horizon = 5,
): Promise<PredictionsResult> {
    const cacheKey = `pred:${lat}:${lon}:${days}:${horizon}`;
    const cached = cacheGet(cacheKey);
    if (cached) return cached;

    // Temperature forecast from historical data
    let tSlope = 0, tIntercept = 20, lastYear = new Date().getFullYear();
    try {
        const meteo = await fetchMeteoSeries(lat, lon, days);
        // Group by year: compute annual mean temperature
        const yearlyMap = new Map<number, { sum: number; count: number }>();
        for (const pt of meteo.temperature) {
            if (pt.mean === null) continue;
            const yr = parseInt(pt.date.slice(0, 4));
            const e = yearlyMap.get(yr) ?? { sum: 0, count: 0 };
            e.sum += pt.mean;
            e.count += 1;
            yearlyMap.set(yr, e);
        }
        const years = Array.from(yearlyMap.entries())
            .sort(([a], [b]) => a - b)
            .map(([yr, { sum, count }]) => ({ yr, avg: sum / count }));

        if (years.length >= 2) {
            const { slope, intercept } = linearRegression(
                years.map((y) => y.yr),
                years.map((y) => y.avg),
            );
            tSlope = slope;
            tIntercept = intercept;
            lastYear = years.at(-1)!.yr;
        }
    } catch {
        // Fallback if API fails
    }

    const temperatureForecast = {
        slope: tSlope,
        intercept: tIntercept,
        forecast: Array.from({ length: horizon }, (_, i) => {
            const year = lastYear + i + 1;
            return { year, pred: tSlope * year + tIntercept };
        }),
    };

    // CO₂ forecast (simulated, rising ~2.5ppm/year from ~421ppm)
    const currentYear = new Date().getFullYear();
    const co2Forecast = {
        slope: 2.5,
        intercept: 421.0,
        forecast: Array.from({ length: horizon }, (_, i) => ({
            year: currentYear + i + 1,
            pred: 421.0 + 2.5 * (i + 1),
        })),
    };

    const result: PredictionsResult = {
        generatedAt: isoDate(new Date()),
        horizonYears: horizon,
        temperatureForecast,
        co2Forecast,
        location: { lat, lon },
        source: 'open-meteo archive (CO₂ simulated at +2.5 ppm/yr)',
    };
    cacheSet(cacheKey, result, 600);
    return result;
}
