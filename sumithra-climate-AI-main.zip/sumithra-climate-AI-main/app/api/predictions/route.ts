import { NextResponse } from 'next/server';
import { buildPredictions } from '@/lib/openmeteo';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const lat = parseFloat(searchParams.get('lat') ?? '12.9716');
    const lon = parseFloat(searchParams.get('lon') ?? '77.5946');
    const days = parseInt(searchParams.get('days') ?? '365');
    const horizon = parseInt(searchParams.get('horizon') ?? '5');

    const data = await buildPredictions(lat, lon, days, horizon);
    return NextResponse.json(data, { status: 200 });
  } catch (e: any) {
    return NextResponse.json(
      { error: 'Failed to compute predictions', detail: e?.message ?? String(e) },
      { status: 500 },
    );
  }
}
