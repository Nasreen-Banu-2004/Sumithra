import { NextResponse } from 'next/server';
import { fetchMeteoSeries, fetchAirQualitySeries } from '@/lib/openmeteo';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const lat = parseFloat(searchParams.get('lat') ?? '12.9716');
    const lon = parseFloat(searchParams.get('lon') ?? '77.5946');
    const days = parseInt(searchParams.get('days') ?? '365');

    const [meteo, air] = await Promise.all([
      fetchMeteoSeries(lat, lon, days),
      fetchAirQualitySeries(lat, lon, 30),
    ]);

    const overview = {
      headline: {
        latestTemp: meteo.latest.temperature,
        latestPrecip: meteo.latest.precipitation,
        latestPM25: air.latest.pm25,
      },
      trends: {
        temperatureMean: meteo.temperature,
        precipitationSum: meteo.precipitation,
      },
      environment: {
        pm25: air.pm25,
      },
      updatedAt: new Date().toISOString(),
      location: meteo.location,
    };

    return NextResponse.json(overview, { status: 200 });
  } catch (e: any) {
    return NextResponse.json(
      { error: 'Failed to build overview', detail: e?.message ?? String(e) },
      { status: 500 },
    );
  }
}
