import { NextResponse } from 'next/server';
import Groq from 'groq-sdk';

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

export async function GET() {
    try {
        const today = new Date().toLocaleDateString('en-US', {
            weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
            timeZone: 'UTC',
        });

        const prompt = `You are ClimateAI, writing the daily global climate briefing for ${today}.

Write a compelling, informative daily climate brief covering:

**🌍 Global Climate Pulse**
A 2-sentence summary of current global climate situation.

**🌡️ Temperature Watch**  
What's notable about temperatures globally right now? Include any anomalies.

**💨 Air Quality Alert**
Current global air quality concerns and regions most affected.

**🌊 Climate Signals**
1-2 significant ongoing climate events (ice melt, extreme weather, droughts, floods).

**🔬 Research Spotlight**
One notable recent climate science finding or trend worth highlighting.

**📅 Forecast Outlook**
Brief 1-week global climate outlook.

Keep it informative, data-driven, and engaging. Use today's date context. Total length ~250 words.`;

        const completion = await groq.chat.completions.create({
            model: 'llama-3.3-70b-versatile',
            messages: [{ role: 'user', content: prompt }],
            temperature: 0.7,
            max_tokens: 600,
        });

        const content = completion.choices[0]?.message?.content ?? 'Briefing unavailable today.';
        return NextResponse.json({ content, date: today });
    } catch (error: any) {
        console.error('[ai/brief]', error);
        return NextResponse.json({ error: error?.message || 'Briefing failed' }, { status: 500 });
    }
}
