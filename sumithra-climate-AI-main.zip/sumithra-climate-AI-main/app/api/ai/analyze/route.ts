import { NextRequest, NextResponse } from 'next/server';
import Groq from 'groq-sdk';

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

export async function POST(req: NextRequest) {
    try {
        const body = await req.json();
        const { temperature, humidity, precipitation, wind, pm25, pm10, ozone, co2, location } = body;

        const dataLines = [
            temperature != null ? `• Temperature: ${temperature}°C` : null,
            humidity != null ? `• Relative Humidity: ${humidity}%` : null,
            precipitation != null ? `• Precipitation: ${precipitation} mm` : null,
            wind != null ? `• Wind Speed: ${wind} m/s` : null,
            pm25 != null ? `• PM2.5: ${pm25} µg/m³ (WHO limit: 15)` : null,
            pm10 != null ? `• PM10: ${pm10} µg/m³ (WHO limit: 45)` : null,
            ozone != null ? `• Ozone: ${ozone} µg/m³` : null,
            co2 != null ? `• CO₂: ${co2} ppm (pre-industrial: 280)` : null,
        ].filter(Boolean).join('\n');

        const prompt = `You are an expert climate scientist. Analyze the following real-time environmental readings${location ? ` for location (Lat: ${location.lat}, Lon: ${location.lon})` : ''}:

${dataLines}

Provide a structured analysis with these exact sections:
**🔴 Risk Level:** (Good / Moderate / Unhealthy / Hazardous)
**📊 Current Conditions:** 2-3 sentences about overall conditions
**⚠️ Key Concerns:** bullet points of any concerning readings
**💡 Recommendations:** 2-3 practical recommendations for residents
**🌍 Climate Context:** brief note on how this fits broader climate trends

Be specific, scientific, and concise.`;

        const completion = await groq.chat.completions.create({
            model: 'llama-3.3-70b-versatile',
            messages: [{ role: 'user', content: prompt }],
            temperature: 0.5,
            max_tokens: 800,
        });

        const content = completion.choices[0]?.message?.content ?? 'Analysis unavailable.';
        return NextResponse.json({ content });
    } catch (error: any) {
        console.error('[ai/analyze]', error);
        return NextResponse.json({ error: error?.message || 'Analysis failed' }, { status: 500 });
    }
}
