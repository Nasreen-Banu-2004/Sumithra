import { NextRequest, NextResponse } from 'next/server';
import Groq from 'groq-sdk';

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

export async function POST(req: NextRequest) {
    try {
        const { messages, context } = await req.json();

        if (!messages || !Array.isArray(messages)) {
            return NextResponse.json({ error: 'messages[] required' }, { status: 400 });
        }

        const systemPrompt = `You are ClimateAI, an expert AI climate researcher and environmental scientist assistant. 
You have deep knowledge in:
- Atmospheric science, meteorology, and climatology
- Air quality, pollution, and public health impacts
- Climate change, carbon cycles, and greenhouse gases
- Environmental risk assessment and adaptation strategies
- Data interpretation of temperature, precipitation, CO₂, PM2.5, ozone, and humidity readings

${context ? `Current environmental context for this location:\n${context}\n` : ''}

Always provide:
1. Clear, scientific explanations accessible to the general public
2. Specific risk assessments (Low / Moderate / High / Severe)
3. Practical recommendations when relevant
4. Exact numbers and units when discussing data
Keep responses concise, insightful, and organized. Use bullet points for lists.`;

        const completion = await groq.chat.completions.create({
            model: 'llama-3.3-70b-versatile',
            messages: [
                { role: 'system', content: systemPrompt },
                ...messages,
            ],
            temperature: 0.6,
            max_tokens: 1024,
        });

        const content = completion.choices[0]?.message?.content ?? 'No response generated.';
        return NextResponse.json({ content });
    } catch (error: any) {
        console.error('[ai/chat]', error);
        return NextResponse.json(
            { error: error?.message || 'AI request failed' },
            { status: 500 }
        );
    }
}
