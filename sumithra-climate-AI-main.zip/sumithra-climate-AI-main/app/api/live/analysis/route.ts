import { NextResponse } from 'next/server';
import { fetchLiveWeather } from '@/lib/openmeteo';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const lat = parseFloat(searchParams.get('lat') ?? '12.9716');
    const lon = parseFloat(searchParams.get('lon') ?? '77.5946');

    const data = await fetchLiveWeather(lat, lon);
    return NextResponse.json(data, { status: 200 });
  } catch (e: any) {
    return NextResponse.json(
      { error: 'Failed to build live analysis', detail: e?.message ?? String(e) },
      { status: 500 },
    );
  }
}
