import { NextResponse } from 'next/server';
import { fetchLiveWeather } from '@/lib/openmeteo';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const lat = parseFloat(searchParams.get('lat') ?? '12.9716');
    const lon = parseFloat(searchParams.get('lon') ?? '77.5946');

    const result = await fetchLiveWeather(lat, lon);
    const c = result.data.current;

    return NextResponse.json({
      temperature: c.temperature_2m ?? null,
      humidity: c.relative_humidity_2m ?? null,
      windSpeed: c.wind_speed_10m ?? null,
      precipitation: c.precipitation ?? null,
      location: `${lat}, ${lon}`,
      timestamp: new Date().toISOString(),
      coordinates: { lat, lon },
      air: result.data.air,
    }, { status: 200 });
  } catch (e: any) {
    return NextResponse.json(
      { error: 'Failed to fetch weather data', message: e?.message ?? String(e) },
      { status: 500 },
    );
  }
}