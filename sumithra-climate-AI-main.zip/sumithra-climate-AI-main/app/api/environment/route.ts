import { NextResponse } from 'next/server';
import { fetchAirQualitySeries } from '@/lib/openmeteo';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const lat = parseFloat(searchParams.get('lat') ?? '12.9716');
    const lon = parseFloat(searchParams.get('lon') ?? '77.5946');
    const days = parseInt(searchParams.get('days') ?? '30');

    const data = await fetchAirQualitySeries(lat, lon, days);

    const pm25 = data.pm25.map((item) => ({
      date: item.date,
      value: item.pm25,
      pm25: item.pm25,
    }));

    return NextResponse.json({
      pm25,
      location: data.location,
      period: data.period,
      latest: data.latest,
    }, { status: 200 });
  } catch (e: any) {
    return NextResponse.json(
      { error: 'Failed to compute environment metrics', detail: e?.message ?? String(e) },
      { status: 500 },
    );
  }
}
