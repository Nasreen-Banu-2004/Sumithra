import { NextResponse } from 'next/server';
import { fetchMeteoSeries, linearRegression } from '@/lib/openmeteo';
import fs from 'fs';
import path from 'path';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const lat = parseFloat(searchParams.get('lat') ?? '12.9716');
    const lon = parseFloat(searchParams.get('lon') ?? '77.5946');
    const days = parseInt(searchParams.get('days') ?? '365');

    const data = await fetchMeteoSeries(lat, lon, days);

    const temperature = data.temperature.map((item) => ({
      date: item.date,
      year: item.date.slice(0, 4),
      value: item.mean,
      anomaly: item.mean !== null ? Number((item.mean - 20).toFixed(1)) : null,
    }));

    const precipitation = data.precipitation.map((item) => ({
      date: item.date,
      year: item.date.slice(0, 4),
      value: item.sum,
      rainfall: item.sum,
    }));

    // Group temperature by year to compute true °C/yr slope
    const yearlyMap = new Map<number, { sum: number; count: number }>();
    for (const pt of data.temperature) {
      if (pt.mean === null) continue;
      const yr = parseInt(pt.date.slice(0, 4));
      const e = yearlyMap.get(yr) ?? { sum: 0, count: 0 };
      e.sum += pt.mean;
      e.count += 1;
      yearlyMap.set(yr, e);
    }
    const years = Array.from(yearlyMap.entries())
      .sort(([a], [b]) => a - b)
      .map(([yr, { sum, count }]) => ({ yr, avg: sum / count }));

    let temperatureTrend = { slope: 0, intercept: 0 };
    if (years.length >= 2) {
      temperatureTrend = linearRegression(years.map(y => y.yr), years.map(y => y.avg));
    }

    // Load CO2 data
    let co2: { year: number, ppm: number }[] = [];
    let co2Trend = { slope: 0, intercept: 0 };
    try {
      const co2Path = path.join(process.cwd(), 'data', 'co2.csv');
      const csv = fs.readFileSync(co2Path, 'utf8');
      const lines = csv.split('\n').slice(1).filter(l => l.trim().length > 0);
      co2 = lines.map(line => {
        const [year, ppm] = line.split(',');
        return { year: parseInt(year), ppm: parseFloat(ppm) };
      });
      if (co2.length >= 2) {
        co2Trend = linearRegression(co2.map(c => c.year), co2.map(c => c.ppm));
      }
    } catch (err) {
      console.error('Failed to parse co2.csv:', err);
    }

    return NextResponse.json({
      temperature,
      temperatureTrend,
      precipitation,
      co2,
      co2Trend,
      location: data.location,
      period: data.period,
    }, { status: 200 });
  } catch (e: any) {
    return NextResponse.json(
      { error: 'Failed to compute trends', detail: e?.message ?? String(e) },
      { status: 500 },
    );
  }
}
