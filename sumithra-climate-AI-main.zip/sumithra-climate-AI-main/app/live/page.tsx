import LiveAIClient from '@/components/LiveAnalysisClient';

export default function LivePage() {
  return <LiveAIClient />;
}
