import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Nav from "@/components/Nav";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Climate AI – Advanced Environmental Analytics",
  description: "AI-powered climate and environmental research platform with real-time analysis",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${inter.variable} antialiased`}>
        <div className="min-h-screen bg-mesh">
          <header className="sticky top-0 z-50">
            <Nav />
          </header>
          <main>{children}</main>
          <footer className="border-t border-[rgba(56,189,248,0.08)] mt-16 py-8 text-center text-sm text-[#475569]">
            <p>
              Climate AI Research Platform •{" "}
              <span className="gradient-cyan-emerald font-medium">Powered by GoGenix-AI</span>
            </p>
            <p className="mt-1">©2026 Sumithra & Team. All rights reserved.</p>
          </footer>
        </div>
      </body>
    </html>
  );
}
