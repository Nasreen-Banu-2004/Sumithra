import InteractiveChart from '@/components/InteractiveChart';
import AIInsightPanel from '@/components/AIInsightPanel';
import { getBaseUrl } from '@/lib/serverUrl';
import { Activity } from 'lucide-react';
import Groq from 'groq-sdk';

async function fetchPredictions(h: number) {
  const base = await getBaseUrl();
  try {
    const res = await fetch(`${base}/api/predictions?horizon=${h}`, { cache: 'no-store' });
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

async function fetchGroqNarrative(data: any, horizon: number): Promise<string> {
  try {
    const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });
    const tForecast = data?.temperatureForecast?.forecast || [];
    const cForecast = data?.co2Forecast?.forecast || [];
    const tSlope = data?.temperatureForecast?.slope;
    const cSlope = data?.co2Forecast?.slope;

    const prompt = `As a climate scientist, analyze these ${horizon}-year projections:

Temperature forecast:
${tForecast.map((d: any) => `  ${d.year}: ${d.pred.toFixed(2)}°C`).join('\n')}
Trend slope: ${tSlope?.toFixed(4)}°C/year

CO₂ forecast:
${cForecast.map((d: any) => `  ${d.year}: ${d.pred.toFixed(1)} ppm`).join('\n')}
Trend slope: ${cSlope?.toFixed(2)} ppm/year

Provide a structured narrative covering:
**🎯 Forecast Summary:** What these numbers mean in plain language
**⚠️ Risk Assessment:** How severe are these projected changes?
**🌍 Real-World Impacts:** 3-4 specific consequences if these trends continue
**💡 Mitigation Pathways:** What actions could change this trajectory
**📊 Confidence Note:** Limitations of linear projection models

Keep it scientifically grounded but accessible (~200 words).`;

    const completion = await groq.chat.completions.create({
      model: 'llama-3.3-70b-versatile',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.6,
      max_tokens: 700,
    });
    return completion.choices[0]?.message?.content ?? '';
  } catch {
    return '';
  }
}

export default async function PredictionsPage({
  searchParams,
}: {
  searchParams?: Promise<{ h?: string }>;
}) {
  const sp = await searchParams;
  const horizon = Math.max(1, Math.min(20, Number(sp?.h ?? '5') || 5));
  const data = await fetchPredictions(horizon);
  const [tFor, cFor, narrative] = await Promise.all([
    Promise.resolve(data?.temperatureForecast?.forecast || []),
    Promise.resolve(data?.co2Forecast?.forecast || []),
    data ? fetchGroqNarrative(data, horizon) : Promise.resolve(''),
  ]);

  const horizonOptions = [3, 5, 10, 15, 20];

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="animate-fade-in-up mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl"
            style={{ background: 'linear-gradient(135deg,#a78bfa,#7c3aed)', boxShadow: '0 0 16px rgba(167,139,250,0.4)' }}>
            <Activity size={18} className="text-gray-950" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight gradient-violet-cyan">AI Climate Forecasts</h1>
        </div>
        <p className="text-slate-400">Linear trend projections with Groq AI narrative analysis.</p>
      </div>

      {/* Horizon selector */}
      <div className="flex items-center gap-3 mb-8 animate-fade-in-up delay-100">
        <span className="text-xs text-slate-500 uppercase tracking-wide">Forecast horizon:</span>
        <div className="flex gap-2 flex-wrap">
          {horizonOptions.map(h => (
            <a
              key={h}
              href={`?h=${h}`}
              className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all"
              style={{
                background: horizon === h ? 'linear-gradient(135deg,#a78bfa,#22d3ee)' : 'rgba(167,139,250,0.08)',
                color: horizon === h ? '#030712' : '#a78bfa',
                border: `1px solid ${horizon === h ? 'transparent' : 'rgba(167,139,250,0.2)'}`,
                fontWeight: horizon === h ? 700 : 500,
              }}
            >
              {h}y
            </a>
          ))}
        </div>
        <span className="text-xs text-slate-500 ml-2">Active: {horizon} years</span>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 mb-8 animate-fade-in-up delay-200">
        <div className="glass-card p-6">
          <h2 className="text-sm font-semibold text-slate-400 mb-1 uppercase tracking-wider">🌡 Temperature Forecast</h2>
          <p className="text-xs text-slate-600 mb-4">Projected mean temperature (°C)</p>
          <InteractiveChart
            data={tFor.map((d: any) => ({ year: String(d.year), value: d.pred }))}
            series={[{ name: 'Predicted °C', dataKey: 'value', color: '#fb923c', fillOpacity: 0.25 }]}
            xKey="year"
            chartType="area"
            showBrush={false}
          />
          {data?.temperatureForecast && (
            <div className="mt-3 text-xs text-slate-500 flex gap-4">
              <span>Slope: <span className="text-orange-400">{data.temperatureForecast.slope.toFixed(4)}°C/yr</span></span>
            </div>
          )}
        </div>
        <div className="glass-card p-6">
          <h2 className="text-sm font-semibold text-slate-400 mb-1 uppercase tracking-wider">🏭 CO₂ Forecast</h2>
          <p className="text-xs text-slate-600 mb-4">Projected CO₂ concentration (ppm)</p>
          <InteractiveChart
            data={cFor.map((d: any) => ({ year: String(d.year), value: d.pred }))}
            series={[{ name: 'Predicted ppm', dataKey: 'value', color: '#34d399', fillOpacity: 0.2 }]}
            xKey="year"
            chartType="area"
            showBrush={false}
          />
          {data?.co2Forecast && (
            <div className="mt-3 text-xs text-slate-500 flex gap-4">
              <span>Slope: <span className="text-emerald-400">+{data.co2Forecast.slope.toFixed(1)} ppm/yr</span></span>
            </div>
          )}
        </div>
      </div>

      {/* Groq AI Narrative */}
      <div className="animate-fade-in-up delay-300">
        <div className="flex items-center gap-2 mb-3">
          <span className="text-sm font-semibold text-slate-300">✦ GoGenix-AI Forecast Narrative</span>
          <span className="badge-ai">MOE-70b</span>
        </div>
        <AIInsightPanel
          content={narrative || 'Add your GROQ_API_KEY to .env.local to generate AI narratives.'}
          title={`${horizon}-Year Forecast Analysis`}
          accentColor="violet"
        />
      </div>
    </div>
  );
}
