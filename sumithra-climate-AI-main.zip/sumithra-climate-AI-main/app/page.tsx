import MetricCard from "@/components/MetricCard";
import InteractiveChart from "@/components/InteractiveChart";
import AIInsightPanel from "@/components/AIInsightPanel";
import { getBaseUrl } from "@/lib/serverUrl";
import { Thermometer, Droplets, Wind, Newspaper } from "lucide-react";
import Groq from "groq-sdk";

async function fetchOverview() {
  const base = await getBaseUrl();
  try {
    const res = await fetch(`${base}/api/overview`, { cache: "no-store" });
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

async function fetchAIBriefing(): Promise<string> {
  try {
    const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });
    const today = new Date().toLocaleDateString("en-US", {
      weekday: "long", year: "numeric", month: "long", day: "numeric",
    });
    const completion = await groq.chat.completions.create({
      model: "llama-3.3-70b-versatile",
      messages: [{
        role: "user",
        content: `Write a concise daily global climate briefing for ${today}. Include: current global temperature trend, notable weather events, air quality highlights, and one actionable insight. Keep it to ~180 words, use emojis for section headers, and make it compelling.`,
      }],
      temperature: 0.7,
      max_tokens: 400,
    });
    return completion.choices[0]?.message?.content ?? "";
  } catch {
    return "";
  }
}

export default async function Home() {
  const [data, briefing] = await Promise.all([fetchOverview(), fetchAIBriefing()]);
  const headline = data?.headline || {};
  const tempSeries = data?.trends?.temperatureMean || [];
  const precipSeries = data?.trends?.precipitationSum || [];

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      {/* Hero */}
      <div className="animate-fade-in-up text-center mb-12">
        <div className="inline-flex items-center gap-2 mb-4">
          <span className="badge-ai text-xs">AI Climate Researcher</span>
          <span className="badge-live text-xs">Live Data</span>
        </div>
        <h1 className="text-5xl font-bold tracking-tight mb-4" style={{ letterSpacing: '-0.03em' }}>
          <span className="gradient-cyan-emerald">Climate Intelligence</span>
          <br />
          <span className="text-slate-300">at Your Fingertips</span>
        </h1>
        <p className="text-slate-400 text-lg max-w-2xl mx-auto">
          Real-time environmental monitoring powered by GoGenix-AI,temperature, air quality,
          predictions, and insights from around the globe.
        </p>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 mb-8 animate-fade-in-up delay-200">
        <MetricCard
          title="Latest Temperature"
          value={headline.latestTemp != null ? Number(headline.latestTemp).toFixed(1) : null}
          unit="°C"
          icon={<Thermometer size={14} className="text-gray-950" />}
          accentColor="rose"
          animDelay={0}
        />
        <MetricCard
          title="Latest Precipitation"
          value={headline.latestPrecip != null ? Number(headline.latestPrecip).toFixed(1) : null}
          unit="mm"
          icon={<Droplets size={14} className="text-gray-950" />}
          accentColor="cyan"
          animDelay={100}
        />
        <MetricCard
          title="Latest PM2.5"
          value={headline.latestPM25 != null ? Number(headline.latestPM25).toFixed(1) : null}
          unit="µg/m³"
          icon={<Wind size={14} className="text-gray-950" />}
          accentColor={
            headline.latestPM25 >= 35 ? "rose" :
              headline.latestPM25 >= 12 ? "amber" :
                "emerald"
          }
          trendValue={
            headline.latestPM25 >= 35 ? "⚠ Unhealthy" :
              headline.latestPM25 >= 12 ? "Moderate" :
                "✓ Good"
          }
          trend={headline.latestPM25 >= 12 ? "up" : "down"}
          animDelay={200}
        />
      </div>

      {/* AI Daily Briefing */}
      {briefing && (
        <div className="mb-8 animate-fade-in-up delay-300">
          <div className="flex items-center gap-2 mb-3">
            <Newspaper size={16} className="text-violet-400" />
            <span className="text-sm font-semibold text-slate-300">AI Daily Climate Briefing</span>
            <span className="text-xs text-slate-500">
              • {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
            </span>
          </div>
          <AIInsightPanel
            content={briefing}
            title="Today's Global Climate Brief"
            accentColor="violet"
            collapsible
          />
        </div>
      )}

      {/* Charts */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 animate-fade-in-up delay-400">
        <div className="glass-card p-6">
          <h2 className="text-sm font-semibold text-slate-400 mb-4 uppercase tracking-wider">
            🌡 Temperature Trend (Daily Mean)
          </h2>
          <InteractiveChart
            data={tempSeries}
            series={[{ name: "Mean °C", dataKey: "mean", color: "#fb7185", fillOpacity: 0.25 }]}
            xKey="date"
            chartType="area"
            showBrush={false}
          />
        </div>
        <div className="glass-card p-6">
          <h2 className="text-sm font-semibold text-slate-400 mb-4 uppercase tracking-wider">
            💧 Precipitation (Daily Sum)
          </h2>
          <InteractiveChart
            data={precipSeries}
            series={[{ name: "mm", dataKey: "sum", color: "#22d3ee", fillOpacity: 0.2 }]}
            xKey="date"
            chartType="area"
            showBrush={false}
          />
        </div>
      </div>

      {/* Quick nav cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8 animate-fade-in-up delay-500">
        {[
          { href: '/trends', label: 'Climate Trends', desc: 'Temp anomaly & CO₂ data', color: '#22d3ee' },
          { href: '/environment', label: 'Air Quality', desc: 'PM2.5, ozone & pollutants', color: '#34d399' },
          { href: '/predictions', label: 'AI Forecasts', desc: '5-year AI projections', color: '#a78bfa' },
          { href: '/live', label: 'Live AI Chat', desc: 'Ask about any location', color: '#fbbf24' },
        ].map(item => (
          <a
            key={item.href}
            href={item.href}
            className="glass-card p-4 block group transition-all"
          >
            <div className="font-semibold text-sm mb-1" style={{ color: item.color }}>
              {item.label}
            </div>
            <div className="text-xs text-slate-500 group-hover:text-slate-400 transition-colors">
              {item.desc}
            </div>
          </a>
        ))}
      </div>
    </div>
  );
}
