'use client';
import { useState, useEffect } from 'react';
import InteractiveChart from '@/components/InteractiveChart';
import AIInsightPanel from '@/components/AIInsightPanel';
import { Wind, Zap, AlertTriangle, CheckCircle2, AlertCircle } from 'lucide-react';

function AQIGauge({ value, label, unit, thresholds }: {
  value: number | null; label: string; unit: string;
  thresholds: { good: number; moderate: number };
}) {
  const level =
    value == null ? 'unknown' :
      value <= thresholds.good ? 'good' :
        value <= thresholds.moderate ? 'moderate' : 'unhealthy';

  const colors = {
    good: { color: '#34d399', bg: 'rgba(52,211,153,0.1)', border: 'rgba(52,211,153,0.25)', Icon: CheckCircle2 },
    moderate: { color: '#fbbf24', bg: 'rgba(251,191,36,0.1)', border: 'rgba(251,191,36,0.25)', Icon: AlertCircle },
    unhealthy: { color: '#fb7185', bg: 'rgba(251,113,133,0.1)', border: 'rgba(251,113,133,0.25)', Icon: AlertTriangle },
    unknown: { color: '#475569', bg: 'rgba(71,85,105,0.1)', border: 'rgba(71,85,105,0.25)', Icon: AlertCircle },
  };
  const c = colors[level];
  const LevelIcon = c.Icon;

  return (
    <div className="glass-card p-5" style={{ borderColor: c.border, background: c.bg }}>
      <div className="flex justify-between items-start mb-3">
        <div className="text-xs text-slate-400 uppercase tracking-wider">{label}</div>
        <LevelIcon size={16} style={{ color: c.color }} />
      </div>
      <div className="text-2xl font-bold mb-1" style={{ color: c.color }}>
        {value?.toFixed(1) ?? '—'} <span className="text-sm font-normal opacity-60">{unit}</span>
      </div>
      <div className="text-xs font-medium capitalize" style={{ color: c.color }}>
        {level === 'unknown' ? 'No data' : level}
      </div>
      {value != null && (
        <div className="mt-2 h-1.5 rounded-full bg-white/5 overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-700"
            style={{
              width: `${Math.min(100, (value / (thresholds.moderate * 1.5)) * 100)}%`,
              background: c.color,
              boxShadow: `0 0 8px ${c.color}`,
            }}
          />
        </div>
      )}
    </div>
  );
}

export default function EnvironmentPage() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [aiAnalysis, setAiAnalysis] = useState('');
  const [aiLoading, setAiLoading] = useState(false);

  useEffect(() => {
    fetch('/api/environment', { cache: 'no-store' })
      .then(r => r.ok ? r.json() : null)
      .then(d => { setData(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  async function runAIAnalysis() {
    setAiLoading(true);
    setAiAnalysis('');
    try {
      const pm25 = data?.latest?.pm25;
      const res = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pm25 }),
      });
      const d = await res.json();
      setAiAnalysis(d.content || d.error || 'No analysis returned.');
    } catch {
      setAiAnalysis('Analysis failed. Please try again.');
    } finally {
      setAiLoading(false);
    }
  }

  const pm25 = data?.pm25 || [];
  const latestPM25 = data?.latest?.pm25 ?? null;

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="animate-fade-in-up mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl"
            style={{ background: 'linear-gradient(135deg,#34d399,#10b981)', boxShadow: '0 0 16px rgba(52,211,153,0.4)' }}>
            <Wind size={18} className="text-gray-950" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight" style={{
            background: 'linear-gradient(135deg,#34d399,#22d3ee)', WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent', backgroundClip: 'text',
          }}>Air Quality Dashboard</h1>
        </div>
        <p className="text-slate-400">Real-time pollutant monitoring with AI-powered health risk assessment.</p>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-24 gap-4">
          <div className="w-12 h-12 rounded-full border-2 border-t-emerald-400 border-transparent animate-spin" />
          <p className="text-slate-500 text-sm">Loading environment data…</p>
        </div>
      ) : (
        <>
          {/* AQI Gauges */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8 animate-fade-in-up delay-100">
            <AQIGauge value={latestPM25} label="PM2.5" unit="µg/m³" thresholds={{ good: 12, moderate: 35 }} />
            <AQIGauge value={data?.latest?.pm10 ?? null} label="PM10" unit="µg/m³" thresholds={{ good: 45, moderate: 75 }} />
            <AQIGauge value={data?.latest?.ozone ?? null} label="Ozone" unit="µg/m³" thresholds={{ good: 100, moderate: 160 }} />
            <AQIGauge value={data?.latest?.co ?? null} label="CO" unit="µg/m³" thresholds={{ good: 4000, moderate: 10000 }} />
          </div>

          {/* PM2.5 Chart */}
          <div className="glass-card p-6 mb-8 animate-fade-in-up delay-200">
            <h2 className="text-sm font-semibold text-slate-400 mb-4 uppercase tracking-wider">📈 PM2.5 Trend (µg/m³)</h2>
            <InteractiveChart
              data={pm25}
              series={[{ name: 'PM2.5 µg/m³', dataKey: 'pm25', color: '#a78bfa', fillOpacity: 0.2 }]}
              xKey="date"
              chartType="area"
              showReferenceLines={true}
            />
            <div className="mt-3 flex gap-6 text-xs text-slate-500">
              <span><span className="text-emerald-400">●</span> Good: ≤ 12</span>
              <span><span className="text-amber-400">●</span> Moderate: 12–35</span>
              <span><span className="text-rose-400">●</span> Unhealthy: &gt; 35</span>
              <span className="ml-auto">WHO 24h guideline: 15 µg/m³</span>
            </div>
          </div>

          {/* AI Analysis */}
          <div className="animate-fade-in-up delay-300">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-slate-300 flex items-center gap-2">
                <Zap size={14} className="text-emerald-400" /> AI Health Risk Assessment
              </h2>
              <button className="btn-primary" onClick={runAIAnalysis} disabled={aiLoading}>
                {aiLoading ? 'Analyzing…' : '✦ Assess with AI'}
              </button>
            </div>
            <AIInsightPanel
              content={aiAnalysis}
              loading={aiLoading}
              title="Air Quality Health Assessment"
              accentColor="emerald"
            />
          </div>
        </>
      )}
    </div>
  );
}
