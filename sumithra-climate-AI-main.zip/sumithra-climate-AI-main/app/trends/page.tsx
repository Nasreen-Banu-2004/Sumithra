'use client';
import { useState, useEffect } from 'react';
import InteractiveChart from '@/components/InteractiveChart';
import AIInsightPanel from '@/components/AIInsightPanel';
import { BarChart3, TrendingUp, Zap } from 'lucide-react';

export default function TrendsPage() {
  const [trendsData, setTrendsData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [aiAnalysis, setAiAnalysis] = useState('');
  const [aiLoading, setAiLoading] = useState(false);

  useEffect(() => {
    fetch('/api/trends', { cache: 'no-store' })
      .then(r => r.ok ? r.json() : null)
      .then(d => { setTrendsData(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  async function runAIAnalysis() {
    if (!trendsData) return;
    setAiLoading(true);
    setAiAnalysis('');
    try {
      const ctx = JSON.stringify({
        temperatureRecords: trendsData.temperature?.length,
        tempTrend: trendsData.temperatureTrend,
        co2Records: trendsData.co2?.length,
        co2Trend: trendsData.co2Trend,
      });
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [{
            role: 'user',
            content: `Analyze these climate trend statistics and explain what they mean for our climate future: ${ctx}. Include what the slope values indicate, whether trends are accelerating, and what we should be most concerned about.`,
          }],
        }),
      });
      const data = await res.json();
      setAiAnalysis(data.content || data.error || 'No response.');
    } catch {
      setAiAnalysis('Failed to get AI analysis. Please try again.');
    } finally {
      setAiLoading(false);
    }
  }

  const temp = trendsData?.temperature || [];
  const co2 = trendsData?.co2 || [];
  const precipSeries = trendsData?.precipitation || [];

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="animate-fade-in-up mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl"
            style={{ background: 'linear-gradient(135deg,#22d3ee,#34d399)', boxShadow: '0 0 16px rgba(34,211,238,0.4)' }}>
            <BarChart3 size={18} className="text-gray-950" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight gradient-cyan-emerald">Climate Trend Analysis</h1>
        </div>
        <p className="text-slate-400">Temperature anomalies, CO₂ concentration, and precipitation patterns over time.</p>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-24 gap-4">
          <div className="w-12 h-12 rounded-full border-2 border-t-cyan-400 border-transparent animate-spin" />
          <p className="text-slate-500 text-sm">Loading climate trend data…</p>
        </div>
      ) : (
        <>
          {/* Stats row */}
          {trendsData && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8 animate-fade-in-up delay-100">
              {[
                { label: 'Temp Records', value: temp.length, color: '#fb7185' },
                { label: 'Temp Slope', value: trendsData.temperatureTrend?.slope?.toFixed(3), suffix: '°C/yr', color: '#fb7185' },
                { label: 'CO₂ Records', value: co2.length, color: '#34d399' },
                { label: 'CO₂ Slope', value: trendsData.co2Trend?.slope?.toFixed(2), suffix: 'ppm/yr', color: '#34d399' },
              ].map(item => (
                <div key={item.label} className="glass-card p-4">
                  <div className="text-xs text-slate-500 uppercase tracking-wider mb-2">{item.label}</div>
                  <div className="text-xl font-bold" style={{ color: item.color }}>
                    {item.value ?? '—'}{item.suffix && <span className="text-sm font-normal ml-1 opacity-70">{item.suffix}</span>}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Charts */}
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2 mb-8 animate-fade-in-up delay-200">
            <div className="glass-card p-6">
              <h2 className="text-sm font-semibold text-slate-400 mb-4 uppercase tracking-wider flex items-center gap-2">
                <TrendingUp size={14} className="text-rose-400" /> Temperature Anomaly
              </h2>
              <InteractiveChart
                data={temp}
                series={[{ name: 'Anomaly (°C)', dataKey: 'anomaly', color: '#fb7185', fillOpacity: 0.25 }]}
                xKey="year"
                chartType="area"
                showReferenceLines={true}
              />
            </div>
            <div className="glass-card p-6">
              <h2 className="text-sm font-semibold text-slate-400 mb-4 uppercase tracking-wider flex items-center gap-2">
                <TrendingUp size={14} className="text-emerald-400" /> CO₂ Concentration
              </h2>
              <InteractiveChart
                data={co2}
                series={[{ name: 'CO₂ (ppm)', dataKey: 'ppm', color: '#34d399', fillOpacity: 0.2 }]}
                xKey="year"
                chartType="area"
              />
            </div>
          </div>

          {/* AI Analysis trigger */}
          <div className="animate-fade-in-up delay-300">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-slate-300 flex items-center gap-2">
                <Zap size={14} className="text-violet-400" />
                GoGenix-AI Trend Interpretation
              </h2>
              <button className="btn-primary" onClick={runAIAnalysis} disabled={aiLoading || !trendsData}>
                {aiLoading ? 'Analyzing…' : '✦ Analyze with AI'}
              </button>
            </div>
            <AIInsightPanel
              content={aiAnalysis}
              loading={aiLoading}
              title="Climate Trend Analysis"
              accentColor="violet"
            />
          </div>
        </>
      )}
    </div>
  );
}
