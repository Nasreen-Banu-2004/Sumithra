'use client';
import { useState, useEffect } from 'react';
import { usePathname } from 'next/navigation';
import { Wind, Activity, BarChart3, Zap, Globe, Menu, X, Cpu } from 'lucide-react';

const links = [
  { href: '/', label: 'Overview', icon: Globe },
  { href: '/trends', label: 'Trends', icon: BarChart3 },
  { href: '/environment', label: 'Environment', icon: Wind },
  { href: '/predictions', label: 'Predictions', icon: Activity },
  { href: '/live', label: 'Live AI', icon: Zap },
];

export default function Nav() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 12);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <nav
        className="transition-all duration-300"
        style={{
          background: scrolled
            ? 'rgba(3, 7, 18, 0.88)'
            : 'rgba(3, 7, 18, 0.55)',
          backdropFilter: 'blur(24px)',
          WebkitBackdropFilter: 'blur(24px)',
          borderBottom: scrolled
            ? '1px solid rgba(56,189,248,0.14)'
            : '1px solid rgba(56,189,248,0.06)',
          boxShadow: scrolled
            ? '0 4px 32px rgba(0,0,0,0.4)'
            : 'none',
        }}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
          {/* Logo */}
          <a href="/" className="flex items-center gap-2.5 group" aria-label="Climate AI Home">
            <div
              className="flex h-8 w-8 items-center justify-center rounded-lg"
              style={{
                background: 'linear-gradient(135deg, #22d3ee, #34d399)',
                boxShadow: '0 0 16px rgba(34, 211, 238, 0.4)',
              }}
            >
              <Cpu size={16} className="text-gray-950" />
            </div>
            <div>
              <span className="gradient-cyan-emerald text-base font-bold tracking-tight">
                Climate AI
              </span>
            </div>
          </a>

          {/* Desktop links */}
          <div className="hidden items-center gap-1 md:flex">
            {links.map(({ href, label, icon: Icon }) => {
              const active = pathname === href;
              return (
                <a
                  key={href}
                  href={href}
                  className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition-all duration-200"
                  style={{
                    background: active ? 'rgba(34, 211, 238, 0.1)' : 'transparent',
                    color: active ? '#22d3ee' : '#94a3b8',
                    border: active ? '1px solid rgba(34,211,238,0.2)' : '1px solid transparent',
                  }}
                  onMouseEnter={e => {
                    if (!active) {
                      (e.currentTarget as HTMLElement).style.color = '#e2e8f0';
                      (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.04)';
                    }
                  }}
                  onMouseLeave={e => {
                    if (!active) {
                      (e.currentTarget as HTMLElement).style.color = '#94a3b8';
                      (e.currentTarget as HTMLElement).style.background = 'transparent';
                    }
                  }}
                >
                  <Icon size={14} />
                  {label}
                </a>
              );
            })}
          </div>

          {/* Mobile toggle */}
          <button
            className="flex items-center justify-center rounded-lg p-2 text-slate-400 transition-colors hover:bg-white/5 hover:text-white md:hidden"
            onClick={() => setOpen(v => !v)}
            aria-label="Toggle menu"
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      {open && (
        <div
          className="fixed inset-x-0 top-[57px] z-40 md:hidden"
          style={{
            background: 'rgba(3, 7, 18, 0.97)',
            backdropFilter: 'blur(24px)',
            borderBottom: '1px solid rgba(56,189,248,0.12)',
          }}
        >
          <div className="flex flex-col gap-1 p-4">
            {links.map(({ href, label, icon: Icon }) => {
              const active = pathname === href;
              return (
                <a
                  key={href}
                  href={href}
                  className="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition-all"
                  style={{
                    background: active ? 'rgba(34,211,238,0.1)' : 'transparent',
                    color: active ? '#22d3ee' : '#94a3b8',
                    border: active ? '1px solid rgba(34,211,238,0.18)' : '1px solid transparent',
                  }}
                  onClick={() => setOpen(false)}
                >
                  <Icon size={16} />
                  {label}
                </a>
              );
            })}
          </div>
        </div>
      )}
    </>
  );
}
