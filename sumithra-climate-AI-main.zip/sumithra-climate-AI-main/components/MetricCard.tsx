'use client';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: number | string | null;
  unit?: string;
  subtitle?: string;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  icon?: React.ReactNode;
  accentColor?: 'cyan' | 'emerald' | 'violet' | 'amber' | 'rose';
  animDelay?: number;
}

const accentMap = {
  cyan: { grad: 'linear-gradient(135deg,#22d3ee,#0ea5e9)', glow: 'rgba(34,211,238,0.3)', border: 'rgba(34,211,238,0.2)' },
  emerald: { grad: 'linear-gradient(135deg,#34d399,#10b981)', glow: 'rgba(52,211,153,0.3)', border: 'rgba(52,211,153,0.2)' },
  violet: { grad: 'linear-gradient(135deg,#a78bfa,#7c3aed)', glow: 'rgba(167,139,250,0.3)', border: 'rgba(167,139,250,0.2)' },
  amber: { grad: 'linear-gradient(135deg,#fbbf24,#f59e0b)', glow: 'rgba(251,191,36,0.3)', border: 'rgba(251,191,36,0.2)' },
  rose: { grad: 'linear-gradient(135deg,#fb7185,#e11d48)', glow: 'rgba(251,113,133,0.3)', border: 'rgba(251,113,133,0.2)' },
};

export default function MetricCard({
  title,
  value,
  unit,
  subtitle,
  trend,
  trendValue,
  icon,
  accentColor = 'cyan',
  animDelay = 0,
}: MetricCardProps) {
  const accent = accentMap[accentColor];

  const TrendIcon = trend === 'up' ? TrendingUp : trend === 'down' ? TrendingDown : Minus;
  const trendColor = trend === 'up' ? '#fb7185' : trend === 'down' ? '#34d399' : '#94a3b8';

  return (
    <div
      className="animate-fade-in-up glass-card p-5"
      style={{
        animationDelay: `${animDelay}ms`,
        borderColor: accent.border,
      }}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <span className="text-xs font-semibold uppercase tracking-widest text-[#64748b]">
          {title}
        </span>
        {icon && (
          <div
            className="flex h-8 w-8 items-center justify-center rounded-lg"
            style={{ background: accent.grad, boxShadow: `0 0 12px ${accent.glow}` }}
          >
            {icon}
          </div>
        )}
      </div>

      {/* Value */}
      <div
        className="text-3xl font-bold tracking-tight"
        style={{
          background: accent.grad,
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          backgroundClip: 'text',
          filter: `drop-shadow(0 0 8px ${accent.glow})`,
        }}
      >
        {value ?? '—'}{unit && <span className="text-lg ml-1 font-normal opacity-70">{unit}</span>}
      </div>

      {/* Trend */}
      {(trend || subtitle) && (
        <div className="mt-2 flex items-center gap-1.5">
          {trend && (
            <TrendIcon size={13} style={{ color: trendColor }} />
          )}
          <span className="text-xs" style={{ color: trend ? trendColor : '#64748b' }}>
            {trendValue || subtitle}
          </span>
        </div>
      )}
    </div>
  );
}
