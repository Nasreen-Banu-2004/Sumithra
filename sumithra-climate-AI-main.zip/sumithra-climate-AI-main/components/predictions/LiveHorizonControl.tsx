'use client';
import { useRouter, useSearchParams } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';

export default function LiveHorizonControl({ initial = 5 }: { initial?: number }) {
  const [value, setValue] = useState<number>(initial);
  const router = useRouter();
  const sp = useSearchParams();

  useEffect(() => {
    const h = sp.get('h');
    if (h) {
      const n = Number(h);
      if (Number.isFinite(n) && n > 0) {
        setValue(n);
      }
    }
  }, [sp]);

  const apply = useCallback(() => {
    const params = new URLSearchParams(sp.toString());
    params.set('h', String(value));
    router.push(`/predictions?${params.toString()}`);
  }, [router, sp, value]);

  return (
    <div className="mt-3 flex items-center gap-3">
      <label className="text-sm text-zinc-700 dark:text-zinc-300">Horizon (years):</label>
      <input
        type="range"
        min={1}
        max={30}
        value={value}
        onChange={(e) => setValue(Number(e.target.value))}
        className="w-56 accent-emerald-600"
      />
      <span className="text-sm font-medium text-zinc-900 dark:text-zinc-100">{value}</span>
      <button
        onClick={apply}
        className="rounded-md bg-gradient-to-r from-sky-500 to-emerald-500 px-3 py-1.5 text-xs font-medium text-white shadow hover:from-sky-600 hover:to-emerald-600"
      >
        Update
      </button>
    </div>
  );
}

