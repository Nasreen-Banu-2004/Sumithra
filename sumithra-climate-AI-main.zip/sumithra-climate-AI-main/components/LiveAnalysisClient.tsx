'use client';
import { useState, useRef, useEffect } from 'react';
import MetricCard from './MetricCard';
import AIInsightPanel from './AIInsightPanel';
import {
  Thermometer, Droplets, Wind, Gauge, MapPin,
  Send, Zap, Bot, Trash2, User,
} from 'lucide-react';

interface ChatMessage { role: 'user' | 'assistant'; content: string; }

const EXAMPLE_QUESTIONS = [
  'Is the air quality safe to exercise outdoors?',
  'What does the precipitation level mean for farming?',
  'Should I be concerned about the wind speed?',
  'How does this compare to global averages?',
];

export default function LiveAnalysisClient() {
  const [lat, setLat] = useState('12.9716');
  const [lon, setLon] = useState('77.5946');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [weatherData, setWeatherData] = useState<any | null>(null);
  const [aiSummary, setAiSummary] = useState('');
  const [aiLoading, setAiLoading] = useState(false);

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [userInput, setUserInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  async function runFetch() {
    setLoading(true);
    setError(null);
    setWeatherData(null);
    setAiSummary('');
    setMessages([]);
    try {
      const url = `/api/live/analysis?lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}`;
      const res = await fetch(url, { cache: 'no-store' });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j?.detail || res.statusText);
      }
      const j = await res.json();
      setWeatherData(j);
      // Trigger AI analysis
      runAIAnalysis(j);
    } catch (e: any) {
      setError(e?.message || 'Request failed');
    } finally {
      setLoading(false);
    }
  }

  async function runAIAnalysis(data: any) {
    setAiLoading(true);
    const c = data?.data?.current || {};
    const air = data?.data?.air || {};
    try {
      const res = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          temperature: c.temperature_2m,
          humidity: c.relative_humidity_2m,
          precipitation: c.precipitation,
          wind: c.wind_speed_10m,
          pm25: air.pm2_5,
          pm10: air.pm10,
          ozone: air.ozone,
          location: data?.location,
        }),
      });
      const d = await res.json();
      setAiSummary(d.content || '');
    } catch {
      setAiSummary('');
    } finally {
      setAiLoading(false);
    }
  }

  async function sendMessage(text?: string) {
    const messageText = text || userInput.trim();
    if (!messageText || chatLoading) return;
    setUserInput('');

    const newMessages: ChatMessage[] = [...messages, { role: 'user', content: messageText }];
    setMessages(newMessages);
    setChatLoading(true);

    const c = weatherData?.data?.current || {};
    const air = weatherData?.data?.air || {};
    const context = weatherData ? `
Location: Lat ${weatherData.location?.lat}, Lon ${weatherData.location?.lon}
Temperature: ${c.temperature_2m}°C, Humidity: ${c.relative_humidity_2m}%, 
Precipitation: ${c.precipitation}mm, Wind: ${c.wind_speed_10m}m/s,
PM2.5: ${air.pm2_5}µg/m³, PM10: ${air.pm10}µg/m³, Ozone: ${air.ozone}µg/m³
` : undefined;

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages.map(m => ({ role: m.role, content: m.content })),
          context,
        }),
      });
      const data = await res.json();
      const assistantMsg = data.content || data.error || 'No response.';
      setMessages(prev => [...prev, { role: 'assistant', content: assistantMsg }]);
    } catch {
      setMessages(prev => [...prev, { role: 'assistant', content: 'Request failed. Please try again.' }]);
    } finally {
      setChatLoading(false);
    }
  }

  const latest = weatherData?.data?.current || {};
  const air = weatherData?.data?.air || {};

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="animate-fade-in-up mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl"
            style={{ background: 'linear-gradient(135deg,#fbbf24,#f59e0b)', boxShadow: '0 0 16px rgba(251,191,36,0.4)' }}>
            <Zap size={18} className="text-gray-950" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight gradient-amber-rose">Live AI Climate Analysis</h1>
          <span className="badge-live">Live</span>
        </div>
        <p className="text-slate-400">Enter any location to get real-time weather data and chat with GoGenix-AI about the conditions.</p>
      </div>

      {/* Location Input */}
      <div className="glass-card p-5 mb-8 animate-fade-in-up delay-100">
        <div className="flex items-center gap-2 mb-4">
          <MapPin size={15} className="text-amber-400" />
          <span className="text-sm font-semibold text-slate-300">Location Coordinates</span>
        </div>
        <div className="flex flex-wrap gap-3 items-end">
          <div>
            <label className="text-xs text-slate-500 mb-1 block">Latitude</label>
            <input className="input-dark w-36" value={lat} onChange={e => setLat(e.target.value)} placeholder="e.g. 12.9716" />
          </div>
          <div>
            <label className="text-xs text-slate-500 mb-1 block">Longitude</label>
            <input className="input-dark w-36" value={lon} onChange={e => setLon(e.target.value)} placeholder="e.g. 77.5946" />
          </div>
          <button className="btn-primary" onClick={runFetch} disabled={loading}>
            {loading ? (
              <span className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-gray-950/30 border-t-gray-950/80 rounded-full animate-spin" />
                Fetching…
              </span>
            ) : '⚡ Analyze Location'}
          </button>
          <div className="flex gap-2 flex-wrap">
            {[
              { label: 'Bengaluru', lat: '12.9716', lon: '77.5946' },
              { label: 'New York', lat: '40.7128', lon: '-74.0060' },
              { label: 'London', lat: '51.5074', lon: '-0.1278' },
            ].map(city => (
              <button
                key={city.label}
                className="btn-ghost text-xs"
                onClick={() => { setLat(city.lat); setLon(city.lon); }}
              >
                {city.label}
              </button>
            ))}
          </div>
        </div>
        {error && (
          <div className="mt-3 rounded-xl px-4 py-3 text-sm text-rose-400"
            style={{ background: 'rgba(251,113,133,0.08)', border: '1px solid rgba(251,113,133,0.2)' }}>
            {error}
          </div>
        )}
      </div>

      {weatherData && (
        <>
          {/* Metric Cards */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-8 animate-fade-in-up">
            <MetricCard title="Temperature" value={latest.temperature_2m?.toFixed(1)} unit="°C" icon={<Thermometer size={13} className="text-gray-950" />} accentColor="rose" />
            <MetricCard title="Humidity" value={latest.relative_humidity_2m?.toFixed(0)} unit="%" icon={<Droplets size={13} className="text-gray-950" />} accentColor="cyan" />
            <MetricCard title="Precipitation" value={latest.precipitation?.toFixed(1)} unit="mm" icon={<Droplets size={13} className="text-gray-950" />} accentColor="cyan" />
            <MetricCard title="Wind Speed" value={latest.wind_speed_10m?.toFixed(1)} unit="m/s" icon={<Wind size={13} className="text-gray-950" />} accentColor="emerald" />
            <MetricCard title="PM2.5" value={air.pm2_5?.toFixed(1)} unit="µg/m³" icon={<Gauge size={13} className="text-gray-950" />} accentColor={air.pm2_5 >= 35 ? 'rose' : air.pm2_5 >= 12 ? 'amber' : 'emerald'} />
            <MetricCard title="Ozone" value={air.ozone?.toFixed(0)} unit="µg/m³" icon={<Gauge size={13} className="text-gray-950" />} accentColor="violet" />
          </div>

          {/* AI Summary */}
          <div className="mb-8 animate-fade-in-up delay-100">
            <AIInsightPanel
              content={aiSummary}
              loading={aiLoading}
              title="AI Environmental Analysis"
              accentColor="cyan"
            />
          </div>

          {/* AI Chat */}
          <div className="glass-card overflow-hidden animate-fade-in-up delay-200">
            {/* Chat Header */}
            <div className="flex items-center justify-between px-5 py-4"
              style={{ borderBottom: '1px solid rgba(251,191,36,0.12)', background: 'rgba(0,0,0,0.2)' }}>
              <div className="flex items-center gap-2.5">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg"
                  style={{ background: 'linear-gradient(135deg,#a78bfa,#22d3ee)' }}>
                  <Bot size={14} className="text-gray-950" />
                </div>
                <span className="text-sm font-semibold text-slate-200">Climate AI Chat</span>
                <span className="badge-ai">Context-Aware</span>
              </div>
              <button
                className="text-slate-600 hover:text-slate-400 transition-colors"
                onClick={() => setMessages([])}
                title="Clear chat"
              >
                <Trash2 size={15} />
              </button>
            </div>

            {/* Messages */}
            <div className="flex flex-col gap-4 px-5 py-5 max-h-96 overflow-y-auto">
              {messages.length === 0 && (
                <div className="space-y-3">
                  <p className="text-xs text-slate-500 text-center py-2">
                    Ask anything about the current conditions at this location
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {EXAMPLE_QUESTIONS.map(q => (
                      <button
                        key={q}
                        onClick={() => sendMessage(q)}
                        className="text-left text-xs px-3 py-2.5 rounded-xl transition-all"
                        style={{
                          background: 'rgba(167,139,250,0.06)',
                          border: '1px solid rgba(167,139,250,0.15)',
                          color: '#94a3b8',
                        }}
                        onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = 'rgba(167,139,250,0.35)'; (e.currentTarget as HTMLElement).style.color = '#c4b5fd'; }}
                        onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = 'rgba(167,139,250,0.15)'; (e.currentTarget as HTMLElement).style.color = '#94a3b8'; }}
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {messages.map((msg, i) => (
                <div key={i} className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  {msg.role === 'assistant' && (
                    <div className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full mt-0.5"
                      style={{ background: 'linear-gradient(135deg,#a78bfa,#22d3ee)' }}>
                      <Bot size={13} className="text-gray-950" />
                    </div>
                  )}
                  <div
                    className="max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed"
                    style={msg.role === 'user' ? {
                      background: 'linear-gradient(135deg,rgba(251,191,36,0.15),rgba(251,191,36,0.08))',
                      border: '1px solid rgba(251,191,36,0.2)',
                      color: '#fef3c7',
                      borderBottomRightRadius: 6,
                    } : {
                      background: 'rgba(167,139,250,0.08)',
                      border: '1px solid rgba(167,139,250,0.15)',
                      color: '#e2e8f0',
                      borderBottomLeftRadius: 6,
                      whiteSpace: 'pre-wrap',
                    }}
                  >
                    {msg.content}
                  </div>
                  {msg.role === 'user' && (
                    <div className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full mt-0.5"
                      style={{ background: 'rgba(251,191,36,0.15)', border: '1px solid rgba(251,191,36,0.2)' }}>
                      <User size={13} className="text-amber-400" />
                    </div>
                  )}
                </div>
              ))}

              {chatLoading && (
                <div className="flex gap-3 justify-start">
                  <div className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full"
                    style={{ background: 'linear-gradient(135deg,#a78bfa,#22d3ee)' }}>
                    <Bot size={13} className="text-gray-950" />
                  </div>
                  <div className="flex items-center gap-1.5 px-4 py-3 rounded-2xl"
                    style={{ background: 'rgba(167,139,250,0.08)', border: '1px solid rgba(167,139,250,0.15)' }}>
                    <div className="typing-dot" />
                    <div className="typing-dot" />
                    <div className="typing-dot" />
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Input */}
            <div className="flex gap-3 px-5 py-4"
              style={{ borderTop: '1px solid rgba(251,191,36,0.08)', background: 'rgba(0,0,0,0.2)' }}>
              <input
                className="input-dark flex-1"
                value={userInput}
                onChange={e => setUserInput(e.target.value)}
                placeholder="Ask about the climate conditions here…"
                onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
                disabled={chatLoading}
              />
              <button
                className="btn-primary px-4"
                onClick={() => sendMessage()}
                disabled={!userInput.trim() || chatLoading}
              >
                <Send size={15} />
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
