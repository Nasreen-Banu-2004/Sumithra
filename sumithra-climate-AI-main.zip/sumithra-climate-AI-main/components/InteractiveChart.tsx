'use client';
import {
  LineChart, Line, AreaChart, Area,
  XAxis, YAxis, Tooltip,
  CartesianGrid, ResponsiveContainer,
  Legend, Brush, ReferenceLine,
} from 'recharts';
import { useState, useEffect, useRef } from 'react';

interface Series {
  name: string;
  dataKey: string;
  color?: string;
  strokeWidth?: number;
  fillOpacity?: number;
}

interface InteractiveChartProps {
  data: any[];
  series: Series[];
  xKey?: string;
  height?: number;
  title?: string;
  showBrush?: boolean;
  showReferenceLines?: boolean;
  chartType?: 'line' | 'area';
  onDataPointClick?: (data: any) => void;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div
        className="px-4 py-3 rounded-xl text-sm"
        style={{
          background: 'rgba(3,7,18,0.95)',
          border: '1px solid rgba(56,189,248,0.2)',
          boxShadow: '0 8px 32px rgba(0,0,0,0.6)',
          backdropFilter: 'blur(16px)',
        }}
      >
        <p className="font-semibold text-slate-300 mb-2">{label}</p>
        {payload.map((entry: any, i: number) => {
          const val = Number(entry.value);
          return (
            <p key={i} style={{ color: entry.color }} className="flex items-center gap-2">
              <span className="inline-block w-2 h-2 rounded-full" style={{ background: entry.color }} />
              {`${entry.name}: ${!isNaN(val) ? val.toFixed(2) : entry.value ?? 'N/A'}`}
            </p>
          );
        })}
      </div>
    );
  }
  return null;
};

export default function InteractiveChart({
  data,
  series,
  xKey = 'date',
  height,
  title,
  showBrush = true,
  showReferenceLines = false,
  chartType = 'area',
  onDataPointClick,
}: InteractiveChartProps) {
  const [autoHeight, setAutoHeight] = useState<number>(height ?? 0);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  useEffect(() => {
    if (height) { setAutoHeight(height); return; }
    function resize() {
      const w = typeof window !== 'undefined' ? window.innerWidth : 1280;
      if (w < 640) setAutoHeight(220);
      else if (w < 1024) setAutoHeight(300);
      else setAutoHeight(360);
    }
    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, [height]);

  const getReferenceLines = () => {
    if (!showReferenceLines || !data.length || !series[0]) return null;
    const values = data.map(item => item[series[0].dataKey]).filter(v => v !== null && v !== undefined);
    if (values.length === 0) return null;
    const avg = values.reduce((s: number, v: number) => s + v, 0) / values.length;
    return (
      <ReferenceLine y={avg} stroke="rgba(167,139,250,0.6)" strokeDasharray="5 3"
        label={{ value: `Avg: ${avg.toFixed(1)}`, fill: '#a78bfa', fontSize: 11 }}
      />
    );
  };

  const gridColor = 'rgba(56,189,248,0.06)';
  const axisColor = '#475569';

  const commonProps = {
    data,
    margin: { top: 8, right: 16, left: 0, bottom: 4 },
    onClick: onDataPointClick,
  };

  const renderSeries = () =>
    series.map((s, i) => {
      const color = s.color || `hsl(${(i * 137.5) % 360}, 70%, 60%)`;
      if (chartType === 'area') {
        return (
          <Area
            key={s.name}
            type="monotone"
            dataKey={s.dataKey}
            name={s.name}
            stroke={color}
            strokeWidth={s.strokeWidth || 2}
            fill={`url(#grad_${i})`}
            dot={false}
            activeDot={{ r: 5, stroke: color, strokeWidth: 2, fill: '#0d1117' }}
            isAnimationActive={true}
            animationDuration={800}
          />
        );
      }
      return (
        <Line
          key={s.name}
          type="monotone"
          dataKey={s.dataKey}
          name={s.name}
          stroke={color}
          strokeWidth={s.strokeWidth || 2}
          dot={false}
          activeDot={{ r: 5, stroke: color, strokeWidth: 2, fill: '#0d1117' }}
          isAnimationActive={true}
          animationDuration={800}
        />
      );
    });

  const ChartWrapper = chartType === 'area' ? AreaChart : LineChart;

  // Prevent Recharts "width(-1) height(-1)" SSR warning by not rendering until mounted client-side
  if (!isMounted) {
    return (
      <div className="w-full">
        {title && (
          <h3 className="text-sm font-semibold text-slate-400 mb-3 text-center uppercase tracking-wider">
            {title}
          </h3>
        )}
        <div
          className="animate-pulse"
          style={{ height: height ?? 300, borderRadius: 8, background: 'rgba(56,189,248,0.04)' }}
        />
      </div>
    );
  }

  return (
    <div className="w-full">
      {title && (
        <h3 className="text-sm font-semibold text-slate-400 mb-3 text-center uppercase tracking-wider">
          {title}
        </h3>
      )}
      <div style={{ height: autoHeight || 300 }}>
        <ResponsiveContainer width="100%" height="100%">
          <ChartWrapper {...commonProps}>
            <defs>
              {series.map((s, i) => {
                const color = s.color || `hsl(${(i * 137.5) % 360}, 70%, 60%)`;
                return (
                  <linearGradient key={i} id={`grad_${i}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={color} stopOpacity={s.fillOpacity ?? 0.3} />
                    <stop offset="100%" stopColor={color} stopOpacity={0.02} />
                  </linearGradient>
                );
              })}
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
            <XAxis
              dataKey={xKey}
              tick={{ fontSize: 11, fill: axisColor }}
              axisLine={{ stroke: gridColor }}
              tickLine={false}
              angle={-25}
              textAnchor="end"
              height={45}
            />
            <YAxis
              tick={{ fontSize: 11, fill: axisColor }}
              axisLine={false}
              tickLine={false}
              width={48}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend
              wrapperStyle={{ fontSize: 12, color: '#64748b', paddingTop: 8 }}
              iconSize={10}
              iconType="circle"
            />
            {getReferenceLines()}
            {renderSeries()}
            {showBrush && data.length > 10 && (
              <Brush
                dataKey={xKey}
                height={24}
                stroke="rgba(56,189,248,0.2)"
                fill="rgba(3,7,18,0.6)"
                travellerWidth={6}
              />
            )}
          </ChartWrapper>
        </ResponsiveContainer>
      </div>
    </div>
  );
}