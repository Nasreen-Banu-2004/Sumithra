'use client';
import { Bot, ChevronDown, ChevronUp, Sparkles } from 'lucide-react';
import { useState } from 'react';

interface AIInsightPanelProps {
    content: string;
    title?: string;
    loading?: boolean;
    error?: string | null;
    collapsible?: boolean;
    accentColor?: 'cyan' | 'violet' | 'emerald';
}

const colors = {
    cyan: { border: 'rgba(34,211,238,0.2)', bg: 'rgba(34,211,238,0.05)', text: '#22d3ee', glow: 'rgba(34,211,238,0.2)' },
    violet: { border: 'rgba(167,139,250,0.2)', bg: 'rgba(167,139,250,0.05)', text: '#a78bfa', glow: 'rgba(167,139,250,0.2)' },
    emerald: { border: 'rgba(52,211,153,0.2)', bg: 'rgba(52,211,153,0.05)', text: '#34d399', glow: 'rgba(52,211,153,0.2)' },
};

export default function AIInsightPanel({
    content,
    title = 'AI Climate Analysis',
    loading = false,
    error = null,
    collapsible = false,
    accentColor = 'violet',
}: AIInsightPanelProps) {
    const [collapsed, setCollapsed] = useState(false);
    const c = colors[accentColor];

    return (
        <div
            className="rounded-2xl overflow-hidden"
            style={{
                background: c.bg,
                border: `1px solid ${c.border}`,
                boxShadow: `0 0 32px ${c.glow}`,
            }}
        >
            {/* Header */}
            <div
                className="flex items-center justify-between px-5 py-3.5"
                style={{ background: 'rgba(0,0,0,0.2)', borderBottom: `1px solid ${c.border}` }}
            >
                <div className="flex items-center gap-2.5">
                    <div
                        className="flex h-7 w-7 items-center justify-center rounded-lg"
                        style={{ background: `linear-gradient(135deg, ${c.text}, rgba(255,255,255,0.6))`, opacity: 0.9 }}
                    >
                        <Bot size={14} className="text-gray-950" />
                    </div>
                    <span className="text-sm font-semibold" style={{ color: c.text }}>{title}</span>
                    <span className="badge-ai">GoGenix-AI</span>
                </div>
                {collapsible && (
                    <button
                        onClick={() => setCollapsed(v => !v)}
                        className="text-slate-500 hover:text-slate-300 transition-colors"
                    >
                        {collapsed ? <ChevronDown size={16} /> : <ChevronUp size={16} />}
                    </button>
                )}
            </div>

            {/* Body */}
            {!collapsed && (
                <div className="px-5 py-4">
                    {loading ? (
                        <div className="flex items-center gap-3 py-2">
                            <Sparkles size={14} className="animate-pulse" style={{ color: c.text }} />
                            <span className="text-sm text-slate-400">GoGenix-AI is analyzing…</span>
                            <div className="flex gap-1 ml-auto">
                                <div className="typing-dot" />
                                <div className="typing-dot" />
                                <div className="typing-dot" />
                            </div>
                        </div>
                    ) : error ? (
                        <div className="rounded-lg px-4 py-3 text-sm text-rose-400"
                            style={{ background: 'rgba(251,113,133,0.08)', border: '1px solid rgba(251,113,133,0.2)' }}>
                            {error}
                        </div>
                    ) : content ? (
                        <div className="text-sm leading-relaxed text-slate-300 whitespace-pre-wrap">
                            {content}
                        </div>
                    ) : (
                        <div className="text-sm text-slate-500 italic py-2">No analysis available yet.</div>
                    )}
                </div>
            )}
        </div>
    );
}
