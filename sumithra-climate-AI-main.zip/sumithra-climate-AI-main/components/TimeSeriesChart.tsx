'use client';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import { useEffect, useState } from 'react';

type Series = {
  name: string;
  dataKey: string;
  color?: string;
};

export default function TimeSeriesChart({
  data,
  series,
  xKey = 'year',
  height,
}: {
  data: any[];
  series: Series[];
  xKey?: string;
  height?: number;
}) {
  const [autoHeight, setAutoHeight] = useState<number>(height ?? 0);
  useEffect(() => {
    if (height) {
      setAutoHeight(height);
      return;
    }
    function resize() {
      const w = typeof window !== 'undefined' ? window.innerWidth : 1280;
      if (w < 640) setAutoHeight(220);
      else if (w < 1024) setAutoHeight(300);
      else setAutoHeight(360);
    }
    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, [height]);
  return (
    <div className="w-full" style={{ height: autoHeight || 280 }}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ left: 8, right: 8, top: 8, bottom: 8 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey={xKey} />
          <YAxis />
          <Tooltip />
          <Legend />
          {series.map((s) => (
            <Line
              key={s.name}
              dot={false}
              type="monotone"
              name={s.name}
              dataKey={s.dataKey}
              stroke={s.color || '#0ea5e9'}
              strokeWidth={2}
              isAnimationActive={false}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
